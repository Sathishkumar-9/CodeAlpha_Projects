# Titanic Exploratory Data Analysis (EDA)

## Project Overview

This project performs Exploratory Data Analysis (EDA) on the Titanic dataset. The objective is to understand passenger information, identify patterns affecting survival, clean the dataset, and visualize important relationships using Python.

---

## Objective

- Load and explore the Titanic dataset.
- Understand the structure of the data.
- Identify and handle missing values.
- Create visualizations to discover patterns.
- Draw meaningful conclusions from the data.

---

## Dataset

Dataset Used: Titanic Dataset (train.csv)

Number of Records: 891

Number of Columns: 12

---

## Tools Used

- Python 3.14
- Visual Studio Code
- Jupyter Notebook

---

## Python Libraries

- Pandas
- NumPy
- Matplotlib
- Seaborn

---

## Project Workflow

1. Imported required libraries.
2. Loaded the Titanic dataset.
3. Explored the dataset using:
   - df.head()
   - df.info()
   - df.describe()
4. Checked missing values.
5. Cleaned the dataset.
6. Removed unnecessary columns.
7. Created visualizations.
8. Analyzed passenger survival patterns.
9. Saved the cleaned dataset.

---

## Visualizations Created

- Survival Count
- Survival by Gender
- Survival by Passenger Class
- Age Distribution
- Fare Distribution
- Correlation Heatmap
- Box Plot
- Pair Plot

---

## Key Findings

- Female passengers had a higher survival rate.
- First-class passengers survived more frequently.
- Most passengers were between 20 and 40 years old.
- Missing values were cleaned successfully.
- No duplicate rows were found.

---

## Output

Cleaned dataset saved as:

output/cleaned_titanic.csv

---

## Conclusion

The Titanic dataset was successfully analyzed using Exploratory Data Analysis techniques. Data cleaning, visualization, and statistical analysis helped identify important trends related to passenger survival.

---

## Author

Name: Sathish

Course: B.Sc Data Science

Project: CodeAlpha(Data Analyst)
         EDA Project
         